<p style="text-align: center;"><strong>一天很短</strong><br /><strong>短得来不及拥抱清晨，</strong><br /><strong>就已经手握黄昏。</strong><br /><strong>一年很短</strong><br /><strong>短得来不及细品初春殷红窦绿，</strong><br /><strong>就要打点素裹秋霜。</strong><br /><strong>一生很短</strong><br /><strong>短的来不及享用美好年华，</strong><br /><strong>就已经身处迟暮。</strong></p>
<p style="text-align: center;">&nbsp;</p>
<h3 style="text-align: center;"><strong>也许我们会自由</strong></h3>
<p>&nbsp;</p>
<p><img src="//image.lceda.cn/pullimage/rS3Lpk58RJzKDsX8AL7PSb9TtPtZmpUWLqetw8Uh.jpeg" alt="" width="1200" height="1092" /></p>
<p>&nbsp;</p>
<h3>这是什么？</h3>
<ul>
<li>你不需要懂我的艺术</li>
<li>是钥匙扣</li>
<li>是项链</li>
<li>是梦</li>
</ul>
<p>&nbsp;</p>
<h3>设计技术点</h3>
<ul>
<li>DFN的STC，高端大气</li>
<li>OLED 0.96 寸</li>
<li>CR1220电池供电</li>
<li>板厚1.6，防呆又防傻，牢固又结实、</li>
</ul>
<p>&nbsp;</p>
<h3>目前问题</h3>
<ul>
<li>没写好多功能</li>
</ul>
<p>&nbsp;</p>
<h3>版本更新日志</h3>
<ul>
<li>v1.1</li>
</ul>
<p>&nbsp; &nbsp; &nbsp; &nbsp; 更新了字库，更换主控芯片，增加按钮功能</p>
<ul>
<li>v1.0</li>
</ul>
<p>&nbsp; &nbsp; &nbsp; &nbsp; 初次验证，由于最近期末考试做的比较简单，之后还需要加上一些其他组件。</p>
<p>&nbsp;</p>
<h3>参考设计</h3>
<p>M.2接口 OLED 0.91'模块（https://oshwhub.com/eedadada/pjm-2-oled0-96）</p>
<p>&nbsp;</p>
<h3>Github源码</h3>
<p>https://github.com/YuzukiHD/Contemporary-Art-Driver</p>
<p>&nbsp;</p>
<h3>一些图片</h3>
<p><img src="//image.lceda.cn/pullimage/SEuyUWlLNYOE0AzOAd5JSICgPerzgBr4Bm468nj5.jpeg" alt="" /></p>
<p>&nbsp;</p>
<h3><img src="//image.lceda.cn/pullimage/hwj2fUY42Cz3ldurlwS4fyRRsnX00DETgzFGRTnq.jpeg" alt="" /></h3>
<h3><br /><img src="//image.lceda.cn/pullimage/AruJMXjs61Gdzo0N3JjTJwkoEWnsHvYsjCLHMPTE.jpeg" alt="" /></h3>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><img src="//image.lceda.cn/pullimage/vV0VAe9vbDBsRl4lrXXZFN9brZe1AKrqNtGHfRb4.jpeg" alt="" /></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.



如何使用：

在编辑器顶部工具栏，点击“文档”图标，选择 “文档” > “打开” > “EasyEDA源码”，选择json文件打开即可。